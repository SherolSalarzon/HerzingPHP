	<footer>
		<h2>Inside the Footer.php</h2>
	</footer>
</body>
</html>