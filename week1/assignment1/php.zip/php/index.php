<?php
	include 'header.php';

	echo 'This is inside index.php';

	include 'footer.php';


?>
